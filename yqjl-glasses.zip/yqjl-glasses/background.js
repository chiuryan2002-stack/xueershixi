// 語義眼鏡: click the toolbar icon (or Alt+G) to toggle highlighting on the current tab.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !/^https?:|^file:/.test(tab.url || '')) return;
  const target = { tabId: tab.id };
  try {
    const [{ result: loaded }] = await chrome.scripting.executeScript({ target, func: () => !!window.YQGlasses });
    if (!loaded) await chrome.scripting.executeScript({ target, files: ['glasses.js'] });
    const [{ result }] = await chrome.scripting.executeScript({ target, func: () => {
      const on = window.YQGlasses.toggle(); const s = window.YQGlasses.stats();
      return { on, n: ['原', '前', '舊', '老'].reduce((a, m) => a + s[m], 0) };
    } });
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: '#668fca' });
    await chrome.action.setBadgeText({ tabId: tab.id, text: result.on ? String(result.n) : '' });
  } catch (e) {
    await chrome.action.setBadgeText({ tabId: tab.id, text: '×' });
  }
});
